# Alpha Bank - Frontend Integrado

Frontend do Alpha Bank totalmente integrado com a API Rust/MySQL.

## 🏗️ Estrutura do Projeto

```
alpha-bank-frontend-integrated/
├── index.html              # Login
├── register.html           # Cadastro
├── welcome.html            # Boas-vindas
├── dashboard.html          # Dashboard principal
├── transactions.html       # Gerenciar transações
├── categories.html         # Gerenciar categorias
├── goals.html              # Metas financeiras
├── recurring.html          # Despesas recorrentes
├── notifications.html      # Notificações
├── stats.html              # Estatísticas
├── simulator.html          # Simulador de orçamento
├── profile.html            # Perfil do usuário
├── settings.html           # Configurações
└── src/
    ├── css/
    │   └── style.css       # Estilos globais
    ├── js/
    │   ├── api.js          # ✨ API integrada com backend
    │   ├── login.js
    │   ├── register.js
    │   ├── dashboard.js
    │   ├── transactions.js
    │   ├── categories.js
    │   ├── goals.js
    │   ├── recurring.js
    │   ├── notifications.js
    │   ├── stats.js
    │   ├── simulator.js
    │   ├── profile.js
    │   ├── settings.js
    │   └── utils.js
    └── assets/
        ├── logo.jpg
        └── (183 SVGs do Figma)
```

## 🔗 Integração com Backend

### API Configurada

O arquivo `src/js/api.js` está **totalmente integrado** com a API Rust.

**URL da API:** `http://localhost:8080/api`

### Autenticação JWT

- Token salvo em `localStorage` como `auth_token`
- Enviado automaticamente em todas as requisições protegidas
- Redirecionamento automático para login se token inválido/expirado

### Endpoints Utilizados

#### Autenticação
- `POST /api/auth/register` - Cadastro
- `POST /api/auth/login` - Login
- `GET /api/me` - Perfil
- `PUT /api/me` - Atualizar perfil
- `POST /api/auth/change-password` - Alterar senha
- `POST /api/auth/forgot-password` - Recuperar senha

#### Transações
- `GET /api/transactions` - Listar
- `POST /api/transactions` - Criar
- `PUT /api/transactions/:id` - Atualizar
- `DELETE /api/transactions/:id` - Deletar

#### Categorias
- `GET /api/categories` - Listar
- `POST /api/categories` - Criar
- `PUT /api/categories/:id` - Atualizar
- `DELETE /api/categories/:id` - Deletar

#### Metas
- `GET /api/goals` - Listar
- `POST /api/goals` - Criar
- `PUT /api/goals/:id` - Atualizar
- `POST /api/goals/:id/progress` - Adicionar progresso
- `DELETE /api/goals/:id` - Deletar

#### Recorrências
- `GET /api/recurring` - Listar
- `POST /api/recurring` - Criar
- `PUT /api/recurring/:id` - Atualizar
- `DELETE /api/recurring/:id` - Deletar
- `POST /api/recurring/generate` - Gerar transações pendentes

#### Notificações
- `GET /api/notifications` - Listar
- `POST /api/notifications` - Criar
- `PUT /api/notifications/:id/read` - Marcar como lida
- `DELETE /api/notifications/:id` - Deletar

## 🚀 Como Executar

### 1. Iniciar o Backend

```bash
cd alpha-bank-backend-mysql
cargo run
```

O backend estará rodando em `http://localhost:8080`

### 2. Servir o Frontend

#### Opção 1: Python (Recomendado)

```bash
cd alpha-bank-frontend-integrated
python -m http.server 3000
```

Acesse: `http://localhost:3000`

#### Opção 2: Node.js

```bash
cd alpha-bank-frontend-integrated
npx http-server -p 3000
```

#### Opção 3: VS Code Live Server

1. Instale a extensão "Live Server"
2. Clique com botão direito em `index.html`
3. Selecione "Open with Live Server"

### 3. Testar

1. Abra `http://localhost:3000`
2. Clique em "Abra sua conta"
3. Preencha o cadastro
4. Faça login
5. Explore todas as funcionalidades!

## 🔧 Configuração

### Alterar URL da API

Edite `src/js/api.js`:

```javascript
const API_BASE_URL = 'http://localhost:8080/api';
// Altere para sua URL de produção quando necessário
```

### CORS

O backend já está configurado para aceitar requisições de qualquer origem durante desenvolvimento.

Para produção, configure o CORS no backend (`main.rs`):

```rust
.wrap(
    Cors::default()
        .allowed_origin("https://seu-dominio.com")
        .allowed_methods(vec!["GET", "POST", "PUT", "DELETE"])
        .allowed_headers(vec![header::AUTHORIZATION, header::CONTENT_TYPE])
        .max_age(3600)
)
```

## ✅ Funcionalidades Integradas

- [x] Autenticação com JWT
- [x] CRUD de Transações
- [x] CRUD de Categorias
- [x] CRUD de Metas Financeiras
- [x] CRUD de Despesas Recorrentes
- [x] CRUD de Notificações
- [x] Perfil do usuário
- [x] Estatísticas e gráficos
- [x] Simulador de orçamento
- [x] Tratamento de erros
- [x] Redirecionamento automático em caso de não autenticado

## 🐛 Troubleshooting

### "Failed to fetch"

**Causa:** Backend não está rodando ou URL incorreta.

**Solução:**
1. Verifique se o backend está rodando: `cargo run`
2. Verifique a URL em `src/js/api.js`
3. Verifique o console do navegador para erros de CORS

### "401 Unauthorized"

**Causa:** Token expirado ou inválido.

**Solução:**
1. Faça logout e login novamente
2. Limpe o localStorage: `localStorage.clear()`

### Dados não aparecem

**Causa:** Backend retornando estrutura diferente.

**Solução:**
1. Verifique o console do navegador
2. Verifique a resposta da API no Network tab
3. Ajuste o mapeamento de campos em `api.js`

## 📝 Notas Importantes

### Diferenças de Nomenclatura

O backend usa **snake_case**, o frontend usa **camelCase**.

O `api.js` faz a conversão automaticamente:

```javascript
// Frontend envia:
{ fullName: "João", birthDate: "1990-01-01" }

// API recebe:
{ full_name: "João", birth_date: "1990-01-01" }
```

### localStorage

Apenas o **token JWT** e **dados do usuário** são salvos no localStorage.

**Todos os outros dados** vêm diretamente da API.

### Simulador de Orçamento

O simulador ainda usa cálculos locais (não há endpoint no backend para isso).

Para integrar, crie um endpoint `/api/simulate` no backend.

## 🎯 Próximos Passos

1. ✅ Backend e Frontend integrados
2. ⏳ Deploy em produção
3. ⏳ Adicionar testes automatizados
4. ⏳ Implementar PWA (Progressive Web App)
5. ⏳ Adicionar notificações push

---

**Frontend 100% integrado com a API Rust!** 🚀


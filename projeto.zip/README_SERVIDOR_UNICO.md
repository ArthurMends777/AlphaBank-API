# 🚀 Alpha Bank - Servidor Único em Rust

Backend e Frontend servidos pelo **mesmo servidor Rust**!

---

## ✨ Novidade

Agora você **não precisa mais** do Python ou Node.js para servir o frontend!

O servidor Rust serve:
- ✅ **API REST** em `/api/*`
- ✅ **Frontend HTML/CSS/JS** em `/`

**Tudo em um único comando:** `cargo run`

---

## 🏗️ Estrutura do Projeto

```
alpha-bank-backend-mysql/
├── src/
│   ├── db/              # Conexão MySQL
│   ├── handlers/        # Controllers da API
│   ├── middleware/      # Auth JWT
│   ├── models/          # Structs
│   ├── utils/           # Helpers
│   └── main.rs          # ✨ Servidor HTTP (API + Frontend)
├── static/              # ✨ Frontend (servido pelo Rust)
│   ├── index.html
│   ├── dashboard.html
│   ├── ... (13 páginas)
│   └── src/
│       ├── css/
│       ├── js/
│       └── assets/
├── schema.sql
├── Cargo.toml
└── .env.example
```

---

## 🚀 Como Executar

### 1. Configurar Banco de Dados

```bash
# No MySQL Workbench, execute:
# 1. Crie o banco: CREATE DATABASE alpha_bank;
# 2. Execute o schema.sql
# 3. Execute o fix_columns.sql (se necessário)
```

### 2. Configurar Variáveis de Ambiente

Crie o arquivo `.env`:

```env
DATABASE_URL=mysql://root:sua_senha@localhost:3306/alpha_bank
JWT_SECRET=seu_secret_super_secreto_aqui_min_32_chars
JWT_EXPIRATION=86400
HOST=127.0.0.1
PORT=8080
RUST_LOG=info
```

### 3. Executar o Servidor

```bash
cargo run
```

**Pronto!** 🎉

---

## 🌐 Acessar

### Frontend (Interface do Usuário)
```
http://localhost:8080
```

### API REST
```
http://localhost:8080/api
```

### Health Check
```
http://localhost:8080/health
```

---

## 📊 Como Funciona

### Rotas do Servidor

| Tipo | Rota | Descrição |
|------|------|-----------|
| **Frontend** | `/` | Página de login (index.html) |
| **Frontend** | `/dashboard.html` | Dashboard |
| **Frontend** | `/src/*` | CSS, JS, Assets |
| **API** | `/api/auth/register` | Cadastro |
| **API** | `/api/auth/login` | Login |
| **API** | `/api/transactions` | Transações |
| **API** | `/api/categories` | Categorias |
| **API** | `/api/goals` | Metas |
| **API** | `/api/recurring` | Recorrências |
| **API** | `/api/notifications` | Notificações |
| **Health** | `/health` | Status do servidor |

### Fluxo de Requisições

```
Navegador
    ↓
http://localhost:8080
    ↓
Servidor Rust (Actix-web)
    ├─→ /api/* → Handlers (MySQL)
    └─→ /* → Arquivos estáticos (static/)
```

---

## 🔧 Configuração do Frontend

O frontend está em `static/` e já está configurado para usar a API local.

**URL da API:** `http://localhost:8080/api` (configurado em `static/src/js/api.js`)

---

## 💡 Vantagens

### Antes (2 servidores)

```bash
# Terminal 1
cargo run

# Terminal 2
cd frontend
python -m http.server 3000
```

Acessar: `http://localhost:3000` → API em `http://localhost:8080`

### Agora (1 servidor)

```bash
cargo run
```

Acessar: `http://localhost:8080` → Tudo no mesmo lugar!

### Benefícios

✅ **Mais simples** - Um único comando  
✅ **Sem CORS** - Mesma origem  
✅ **Mais rápido** - Menos overhead  
✅ **Produção-ready** - Deploy único  
✅ **Foco no Rust** - Tudo em Rust! 🦀  

---

## 📝 Logs do Servidor

Ao executar `cargo run`, você verá:

```
🚀 Starting Alpha Bank Server at http://127.0.0.1:8080
📊 Database connected successfully
🌐 Frontend available at http://127.0.0.1:8080
🔌 API available at http://127.0.0.1:8080/api
```

---

## 🧪 Testar

### 1. Frontend

Abra o navegador em `http://localhost:8080`

Você deve ver a tela de login do Alpha Bank.

### 2. API

```bash
# Health check
curl http://localhost:8080/health

# Registrar usuário
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "full_name": "Teste",
    "email": "teste@test.com",
    "password": "123456",
    "cpf": "123.456.789-00",
    "birth_date": "1990-01-01",
    "phone": "(11) 99999-9999"
  }'
```

---

## 🔧 Personalizar

### Alterar Porta

Edite `.env`:

```env
PORT=3000
```

Agora o servidor rodará em `http://localhost:3000`

### Alterar Host

Para aceitar conexões externas:

```env
HOST=0.0.0.0
```

---

## 📦 Deploy em Produção

### 1. Build Release

```bash
cargo build --release
```

### 2. Copiar Arquivos

```bash
# Binário
./target/release/alpha-bank-backend

# Frontend
./static/
```

### 3. Executar

```bash
./alpha-bank-backend
```

### 4. Configurar Nginx (Opcional)

```nginx
server {
    listen 80;
    server_name alphabank.com;

    location / {
        proxy_pass http://localhost:8080;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## 🎯 Dependências Adicionadas

No `Cargo.toml`:

```toml
actix-files = "0.6"  # ✨ Para servir arquivos estáticos
```

No `main.rs`:

```rust
use actix_files as fs;

// ...

.service(fs::Files::new("/src", "./static/src"))
.service(
    fs::Files::new("/", "./static")
        .index_file("index.html")
)
```

---

## ✅ Checklist

- [x] Backend Rust funcionando
- [x] Frontend integrado
- [x] Servidor único
- [x] API REST completa
- [x] Autenticação JWT
- [x] MySQL integrado
- [x] Arquivos estáticos servidos
- [x] CORS configurado
- [x] Logs informativos

---

## 🎉 Resultado

**Um único servidor Rust** servindo:
- ✅ API REST completa (31 endpoints)
- ✅ Frontend HTML/CSS/JS
- ✅ Autenticação JWT
- ✅ Banco de dados MySQL

**Tudo rodando em `http://localhost:8080`**

**100% Rust!** 🦀🚀

---

## 📚 Comandos Úteis

```bash
# Desenvolvimento
cargo run

# Produção
cargo build --release
./target/release/alpha-bank-backend

# Limpar build
cargo clean

# Verificar código
cargo check

# Formatar código
cargo fmt

# Linter
cargo clippy
```

---

**Projeto completo e pronto para apresentação!** 🎊

